import { useEffect, useState } from "react";
import { api } from "../services/api";
import type { HealthResponse } from "../types/api";

export type HealthState =
  | { kind: "loading" }
  | { kind: "ok"; data: HealthResponse }
  | { kind: "error"; message: string };

/** Polls the backend health endpoint so the header can show real status. */
export function useHealth(intervalMs = 15000): HealthState {
  const [state, setState] = useState<HealthState>({ kind: "loading" });

  useEffect(() => {
    let cancelled = false;
    const check = async () => {
      try {
        const data = await api.health();
        if (!cancelled) setState({ kind: "ok", data });
      } catch (e) {
        if (!cancelled)
          setState({ kind: "error", message: e instanceof Error ? e.message : "Unknown error" });
      }
    };
    void check();
    const id = setInterval(() => void check(), intervalMs);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, [intervalMs]);

  return state;
}
