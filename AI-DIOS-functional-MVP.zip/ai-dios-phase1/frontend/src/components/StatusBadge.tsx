import type { HealthState } from "../hooks/useHealth";

export function StatusBadge({ health }: { health: HealthState }) {
  const map = {
    loading: { dot: "bg-slate-400", text: "Checking API…" },
    ok: { dot: "bg-sev-low", text: "API online" },
    error: { dot: "bg-sev-critical", text: "API offline" },
  } as const;
  const { dot, text } = map[health.kind];
  return (
    <span
      role="status"
      className="inline-flex items-center gap-2 rounded-full border border-ink-600 bg-ink-800 px-3 py-1 text-xs"
    >
      <span className={`h-2 w-2 rounded-full ${dot}`} aria-hidden="true" />
      {text}
    </span>
  );
}
