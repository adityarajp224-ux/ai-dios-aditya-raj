import { NavLink, Outlet } from "react-router-dom";
import { useHealth } from "../hooks/useHealth";
import { StatusBadge } from "./StatusBadge";

const NAV = [
  { to: "/", label: "Overview", end: true },
  { to: "/ingestion", label: "Data Ingestion" },
  { to: "/incidents", label: "Incidents" },
  { to: "/analytics", label: "Analytics" },
  { to: "/model", label: "Model Evaluation" },
  { to: "/settings", label: "Settings" },
];

export function Layout() {
  const health = useHealth();
  return (
    <div className="flex min-h-screen flex-col md:flex-row">
      <aside className="border-b border-ink-700 bg-ink-900 md:w-60 md:border-b-0 md:border-r">
        <div className="px-5 py-5">
          <div className="text-lg font-semibold tracking-wide text-brand-400">AI-DIOS</div>
          <div className="text-xs text-slate-400">Cybersecurity Decision Support</div>
        </div>
        <nav aria-label="Main" className="flex gap-1 overflow-x-auto px-3 pb-3 md:flex-col md:pb-0">
          {NAV.map((n) => (
            <NavLink
              key={n.to}
              to={n.to}
              end={n.end}
              className={({ isActive }) =>
                `whitespace-nowrap rounded-md px-3 py-2 text-sm transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-400 ${
                  isActive
                    ? "bg-ink-700 text-white"
                    : "text-slate-300 hover:bg-ink-800 hover:text-white"
                }`
              }
            >
              {n.label}
            </NavLink>
          ))}
        </nav>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center justify-between gap-3 border-b border-ink-700 bg-ink-900 px-6 py-3">
          <span className="text-sm text-slate-400">Local academic prototype</span>
          <StatusBadge health={health} />
        </header>
        <main className="flex-1 p-6">
          <Outlet context={health} />
        </main>
      </div>
    </div>
  );
}
