import type { ReactNode } from "react";

export function Card({ title, children }: { title?: string; children: ReactNode }) {
  return (
    <section className="rounded-lg border border-ink-700 bg-ink-800 p-5">
      {title && <h2 className="mb-3 text-sm font-semibold text-slate-100">{title}</h2>}
      {children}
    </section>
  );
}
