import type { HealthResponse, DatasetImport, Incident, Summary } from "../types/api";
const BASE_URL: string = import.meta.env.VITE_API_BASE_URL ?? "http://localhost:8000/api/v1";
export class ApiError extends Error { status: number | null; constructor(message: string, status: number | null = null) { super(message); this.name = "ApiError"; this.status = status; } }
async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let res: Response;
  try { res = await fetch(`${BASE_URL}${path}`, init); }
  catch { throw new ApiError("Cannot reach the AI-DIOS backend. Is it running on port 8000?"); }
  if (!res.ok) { let detail = `Request failed (${res.status})`; try { const body = await res.json(); detail = body.detail ?? detail; } catch {} throw new ApiError(detail, res.status); }
  return await res.json() as T;
}
export const api = {
  health: () => request<HealthResponse>("/health"),
  datasets: () => request<DatasetImport[]>("/datasets"),
  upload: (file: File) => { const body = new FormData(); body.append("file", file); return request<{id:number;filename:string;total_rows:number;accepted_rows:number;rejected_rows:number;errors:string[];status:string;message:string}>("/datasets/upload", { method:"POST", body }); },
  runAnalysis: (id:number) => request<{dataset_id:number;events_analyzed:number;incidents_created:number;incidents:Incident[]}>(`/analysis/run?dataset_id=${id}`, {method:"POST"}),
  incidents: (datasetId?:number) => request<Incident[]>(`/incidents${datasetId ? `?dataset_id=${datasetId}` : ""}`),
  incident: (id:number) => request<Incident>(`/incidents/${id}`),
  updateIncident: (id:number,status:string) => request<Incident>(`/incidents/${id}`, {method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({status})}),
  summary: () => request<Summary>("/dashboard/summary"),
  analytics: () => request<{categories:{name:string;count:number}[];statuses:{name:string;count:number}[]}>("/analytics"),
};
