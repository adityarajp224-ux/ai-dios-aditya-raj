export interface HealthResponse { status: string; app: string; version: string; environment: string; database: string; }
export interface DatasetImport { id: number; filename: string; imported_at?: string; total_rows: number; accepted_rows: number; rejected_rows: number; status: string; }
export interface Incident { id: number; dataset_id: number; title: string; category: string; source_ip: string; severity: string; risk_score: number; summary: string; evidence: Record<string, unknown>; recommendation: string; first_seen: string; last_seen: string; status: string; }
export interface Summary { total_events: number; total_incidents: number; high_priority: number; imports: number; by_severity: Record<string, number>; recent_incidents: Incident[]; }
