import { useCallback, useEffect, useState } from "react";
import { api } from "../services/api";
import type { DatasetImport } from "../types/api";
import { Card } from "../components/Card";

export function Ingestion() {
  const [file,setFile] = useState<File|null>(null);
  const [busy,setBusy] = useState(false);
  const [error,setError] = useState("");
  const [result,setResult] = useState<{id:number;filename:string;total_rows:number;accepted_rows:number;rejected_rows:number;errors:string[];status:string;message:string}|null>(null);
  const [datasets,setDatasets] = useState<DatasetImport[]>([]);
  const [analysis,setAnalysis] = useState<{dataset_id:number;events_analyzed:number;incidents_created:number}|null>(null);
  const refresh = useCallback(async () => { try { setDatasets(await api.datasets()); } catch(e) { setError(e instanceof Error?e.message:"Unable to load imports"); } }, []);
  useEffect(()=>{void refresh()},[refresh]);
  const upload = async () => { if(!file)return; setBusy(true);setError("");setResult(null);setAnalysis(null);try {const r=await api.upload(file);setResult(r);await refresh();}catch(e){setError(e instanceof Error?e.message:"Upload failed");}finally{setBusy(false)} };
  const run = async (id:number) => {setBusy(true);setError("");try{const r=await api.runAnalysis(id);setAnalysis({dataset_id:r.dataset_id,events_analyzed:r.events_analyzed,incidents_created:r.incidents_created});}catch(e){setError(e instanceof Error?e.message:"Analysis failed")}finally{setBusy(false)}};
  return <div className="space-y-6"><div><h1 className="text-2xl font-semibold">Data Ingestion</h1><p className="mt-1 text-sm text-slate-400">Import security events, validate records, and run analysis.</p></div>
    <Card title="Upload security-event CSV"><p className="mb-4 text-sm text-slate-400">Required columns: timestamp, source_ip, event_type, action. Optional: destination_ip, destination_port, username, protocol, bytes_out. CSV only, maximum 5 MB.</p>
      <div className="flex flex-wrap items-center gap-3"><input aria-label="CSV file" type="file" accept=".csv,text/csv" onChange={e=>{setFile(e.target.files?.[0]??null);setResult(null);setError("")}} className="max-w-full text-sm text-slate-300 file:mr-3 file:rounded-md file:border-0 file:bg-slate-700 file:px-3 file:py-2 file:text-white"/>
      <button disabled={!file||busy} onClick={()=>void upload()} className="rounded-md bg-sky-500 px-4 py-2 text-sm font-semibold text-slate-950 disabled:opacity-50">{busy?"Working…":"Upload and validate"}</button></div>
      {error&&<p role="alert" className="mt-4 text-sm text-red-300">{error}</p>}
      {result&&<div className="mt-5 rounded-lg border border-slate-700 bg-slate-900 p-4"><h3 className="font-semibold">Import #{result.id}: {result.filename}</h3><p className="mt-2 text-sm text-slate-300">{result.message}</p><div className="mt-3 grid grid-cols-2 gap-3 md:grid-cols-4">{[["Rows",result.total_rows],["Accepted",result.accepted_rows],["Rejected",result.rejected_rows],["Status",result.status]].map(([k,v])=><div key={String(k)} className="rounded bg-slate-800 p-3"><div className="text-xs text-slate-400">{k}</div><div className="mt-1 text-lg font-semibold">{v}</div></div>)}</div>{result.errors.length>0&&<div className="mt-3 text-sm text-amber-200"><p className="font-medium">Validation notes</p><ul className="mt-1 list-inside list-disc">{result.errors.map((e,i)=><li key={i}>{e}</li>)}</ul></div>}{result.accepted_rows>0&&<button disabled={busy} onClick={()=>void run(result.id)} className="mt-4 rounded-md bg-emerald-400 px-4 py-2 text-sm font-semibold text-slate-950 disabled:opacity-50">Run threat analysis</button>}</div>}
      {analysis&&<div className="mt-4 rounded-lg border border-emerald-700 bg-emerald-950/40 p-4"><p className="font-semibold text-emerald-200">Analysis completed for import #{analysis.dataset_id}</p><p className="mt-1 text-sm">Events analyzed: {analysis.events_analyzed} · Incidents created: {analysis.incidents_created}</p><a href="/incidents" className="mt-3 inline-block text-sm text-sky-300 underline">View incidents</a></div>}
    </Card>
    <Card title="Import history">{datasets.length===0?<p className="text-sm text-slate-400">No imports yet. Upload a CSV to begin.</p>:<div className="overflow-x-auto"><table className="w-full text-left text-sm"><thead className="text-slate-400"><tr><th className="p-2">ID / File</th><th className="p-2">Rows</th><th className="p-2">Accepted</th><th className="p-2">Rejected</th><th className="p-2">Action</th></tr></thead><tbody>{datasets.map(d=><tr key={d.id} className="border-t border-slate-700"><td className="p-2">#{d.id} · {d.filename}</td><td className="p-2">{d.total_rows}</td><td className="p-2">{d.accepted_rows}</td><td className="p-2">{d.rejected_rows}</td><td className="p-2"><button onClick={()=>void run(d.id)} disabled={busy||d.accepted_rows===0} className="rounded bg-slate-700 px-2 py-1 text-xs hover:bg-slate-600 disabled:opacity-50">Run analysis</button></td></tr>)}</tbody></table></div>}</Card>
  </div>;
}
