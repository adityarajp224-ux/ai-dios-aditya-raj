import { useEffect, useState } from "react";
import { useOutletContext, Link } from "react-router-dom";
import { Card } from "../components/Card";
import type { HealthState } from "../hooks/useHealth";
import type { Summary } from "../types/api";
import { api } from "../services/api";
export function Overview() {
 const health=useOutletContext<HealthState>();const [summary,setSummary]=useState<Summary|null>(null);const [error,setError]=useState("");
 useEffect(()=>{api.summary().then(setSummary).catch(e=>setError(e instanceof Error?e.message:"Could not load dashboard"))},[]);
 const metrics=[["Security events",summary?.total_events??"—"],["Incidents",summary?.total_incidents??"—"],["High / Critical",summary?.high_priority??"—"],["Dataset imports",summary?.imports??"—"]];
 return <div className="space-y-6"><div><h1 className="text-2xl font-semibold text-white">Overview</h1><p className="mt-1 text-sm text-slate-400">Security event analysis and decision support.</p></div>
 <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">{metrics.map(([label,value])=><div key={label} className="rounded-lg border border-ink-700 bg-ink-800 p-4"><p className="text-sm text-slate-400">{label}</p><p className="mt-2 text-3xl font-semibold">{value}</p></div>)}</div>
 <Card title="Backend connection">{health.kind==="loading"&&<p className="text-slate-400">Contacting API…</p>}{health.kind==="error"&&<p role="alert" className="text-red-300">{health.message}</p>}{health.kind==="ok"&&<dl className="grid grid-cols-2 gap-3 text-sm sm:grid-cols-4"><div><dt className="text-slate-400">App</dt><dd>{health.data.app}</dd></div><div><dt className="text-slate-400">Version</dt><dd>{health.data.version}</dd></div><div><dt className="text-slate-400">Environment</dt><dd>{health.data.environment}</dd></div><div><dt className="text-slate-400">Database</dt><dd>{health.data.database}</dd></div></dl>}</Card>
 {error&&<p role="alert" className="text-sm text-amber-200">{error}</p>}
 <div className="grid gap-4 lg:grid-cols-2"><Card title="Incidents by severity">{summary?Object.entries(summary.by_severity).map(([s,n])=><div key={s} className="mb-3"><div className="mb-1 flex justify-between text-sm"><span>{s}</span><span>{n}</span></div><div className="h-2 rounded bg-slate-700"><div className={`h-2 rounded ${s==="Critical"?"bg-red-500":s==="High"?"bg-orange-500":s==="Medium"?"bg-yellow-400":"bg-emerald-500"}`} style={{width:`${summary.total_incidents?Math.max(n/summary.total_incidents*100,n?4:0):0}%`}}/></div></div>):<p className="text-sm text-slate-400">Loading summary…</p>}</Card>
 <Card title="Recent incidents">{summary?.recent_incidents.length?summary.recent_incidents.map(i=><div key={i.id} className="border-b border-slate-700 py-3 last:border-0"><div className="flex items-center justify-between gap-3"><span className="text-sm font-medium">{i.title}</span><span className="rounded bg-slate-700 px-2 py-1 text-xs">{i.risk_score}/100</span></div><p className="mt-1 text-xs text-slate-400">{i.source_ip} · {i.severity} · {i.status}</p></div>):<p className="text-sm text-slate-400">No incidents yet. <Link to="/ingestion" className="text-sky-300 underline">Import a sample CSV</Link> and run analysis.</p>}</Card></div>
 <Card title="Quick start"><p className="text-sm text-slate-300">Upload security-event CSV data, run the rule-based analysis, then inspect evidence-backed findings. Demo data is synthetic and must not be interpreted as real network telemetry.</p><Link to="/ingestion" className="mt-3 inline-block rounded bg-sky-500 px-4 py-2 text-sm font-semibold text-slate-950">Go to Data Ingestion</Link></Card>
 </div>;
}
