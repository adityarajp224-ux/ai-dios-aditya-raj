import { Card } from "../components/Card";

export function Placeholder({ title, phase }: { title: string; phase: string }) {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold text-white">{title}</h1>
      <Card>
        <p className="text-sm text-slate-400">
          Status: <span className="font-medium text-slate-200">Planned</span> — scheduled for{" "}
          {phase}. Nothing is implemented on this page yet.
        </p>
      </Card>
    </div>
  );
}
