import { useEffect, useState } from "react";
import { Card } from "../components/Card";
import { api } from "../services/api";
export function Analytics(){
 const [data,setData]=useState<{categories:{name:string;count:number}[];statuses:{name:string;count:number}[]}|null>(null);const [error,setError]=useState("");
 useEffect(()=>{api.analytics().then(setData).catch(e=>setError(e instanceof Error?e.message:"Unable to load analytics"))},[]);
 return <div className="space-y-6"><div><h1 className="text-2xl font-semibold">Analytics</h1><p className="mt-1 text-sm text-slate-400">Aggregated views of incidents generated from imported datasets.</p></div>{error&&<p role="alert" className="text-sm text-red-300">{error}</p>}
 <div className="grid gap-4 lg:grid-cols-2"><Card title="Incidents by category">{data?.categories.length?data.categories.map(c=><div key={c.name} className="mb-4"><div className="mb-1 flex justify-between text-sm"><span>{c.name}</span><span>{c.count}</span></div><div className="h-2 rounded bg-slate-700"><div className="h-2 rounded bg-sky-400" style={{width:`${Math.min(100,c.count/Math.max(...data.categories.map(x=>x.count))*100)}%`}}/></div></div>):<p className="text-sm text-slate-400">No incident analytics yet. Import data and run analysis.</p>}</Card>
 <Card title="Incident workflow status">{data?.statuses.length?data.statuses.map(s=><div key={s.name} className="flex justify-between border-b border-slate-700 py-3 text-sm last:border-0"><span>{s.name}</span><span className="font-semibold">{s.count}</span></div>):<p className="text-sm text-slate-400">No incidents to summarize.</p>}</Card></div>
 <Card title="Interpretation"><p className="text-sm text-slate-300">These charts summarize incidents stored in the local database. Rule-based indicators are heuristic and can produce false positives. A detected pattern is not proof of malicious intent.</p></Card></div>
}
