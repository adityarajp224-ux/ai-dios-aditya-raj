import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Layout } from "../components/Layout";
import { Overview } from "../pages/Overview";
import { Ingestion } from "../pages/Ingestion";
import { Incidents } from "../pages/Incidents";
import { Analytics } from "../pages/Analytics";
import { Settings } from "../pages/Settings";
import { Placeholder } from "../pages/Placeholder";
export function App() {
 return <BrowserRouter><Routes><Route element={<Layout />}>
 <Route index element={<Overview />} />
 <Route path="ingestion" element={<Ingestion />} />
 <Route path="incidents" element={<Incidents />} />
 <Route path="analytics" element={<Analytics />} />
 <Route path="model" element={<Placeholder title="Model Evaluation" phase="Phase 5" />} />
 <Route path="settings" element={<Settings />} />
 <Route path="*" element={<Placeholder title="Page not found" phase="n/a" />} />
 </Route></Routes></BrowserRouter>;
}
