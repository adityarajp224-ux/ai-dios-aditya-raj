# AI-DIOS Development Status

## Functional in this build
- Local React/TypeScript frontend and FastAPI API.
- Health endpoint with database connectivity status.
- CSV upload with required-column checks, IP/timestamp validation, numeric range validation, file-size and row limits.
- Dataset import history and SQLite persistence.
- Deterministic synthetic data generator.
- Rule-based analysis for repeated failed/denied events and broad destination-port activity.
- Incident evidence, heuristic risk scores, severity, recommendations, status updates.
- Dashboard KPIs and category/status analytics derived from the database.

## Tested
Record test outcomes from the actual machine where commands are run. Do not treat source-code generation as proof of successful execution.

## Not implemented
- Trained ML model, benchmark dataset evaluation, calibrated probabilities.
- Authentication / multi-user authorization.
- Live network telemetry, SIEM integration, automated response.
- Production hardening and deployment.

## Heuristic definitions
- AUTH-001: at least five failed/denied events associated with a source IP.
- NET-001: at least eight distinct destination ports associated with a source IP.
These thresholds are demonstration choices and may produce false positives/negatives.
