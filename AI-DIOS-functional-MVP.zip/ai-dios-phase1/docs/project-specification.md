AI-DIOS — Intelligent Analytics & Cybersecurity Decision Support System

# Master Project Build Specification & AI Coding-Agent Brief

**Purpose: This document is the single source of truth for AI coding tools (Claude, ChatGPT, Cursor, Windsurf, or similar) to help plan, implement, test, and document the AI-DIOS B.Tech final-year capstone project.**

**Project status at the time this brief was created: Not yet implemented. This is a proposed design and build plan, not evidence of completed work. All implementation status, test outcomes, metrics, and screenshots must be updated only after actual work is performed.**

# PART A — COPY-PASTE MASTER PROMPT FOR AN AI CODING AGENT

You are acting as a senior full-stack engineer, applied machine-learning engineer, cybersecurity analyst, QA engineer, and technical mentor. Help me build a complete, reproducible, locally runnable B.Tech capstone project called AI-DIOS — Intelligent Analytics & Cybersecurity Decision Support System.

# 1. Mission and expected outcome

Build a functional cybersecurity analytics and decision-support web application that ingests security-event data, validates and preprocesses it, uses transparent rule-based detection and a machine-learning component where appropriate, computes risk scores, prioritizes incidents, explains why an event was flagged, and recommends defensive actions to a human analyst.

This must be a real working software project—not only a UI mockup, static dashboard, report, or set of unconnected code snippets.

## Core pipeline

CSV / sample event data → validation → preprocessing and feature extraction → detection/classification → risk scoring → explainable findings → recommended response → dashboard and incident details

The first version must work locally without requiring paid APIs, cloud accounts, a live enterprise network, or real production credentials. External LLM integration may be optional and must not be required for core functionality.

# 2. Important truthfulness and implementation rules

The project has not yet been implemented. Do not describe planned functionality as completed.

Never invent test results, dataset counts, accuracy, precision, recall, F1-score, latency, screenshots, or benchmark claims.

Use clearly labelled synthetic/demo data if no real dataset has yet been selected. Do not imply synthetic data came from a real network.

For any dataset, document the source, license/terms, date obtained, file name, row count, label distribution, feature definitions, preprocessing, and any limitations.

Do not claim that an ML model detects real-world attacks reliably solely because it performs well on one dataset.

Separate rule-based alerts from ML predictions. Label the source of each finding.

Risk scores are decision-support indicators, not proof that a host or IP is malicious. Explain score inputs and thresholds.

Do not automatically block IP addresses, change firewall rules, disable accounts, scan third-party systems, or perform other disruptive actions. Show recommended actions for a human to approve.

Never expose secrets, API keys, passwords, or personal data in source code or logs. Use environment variables and `.env.example`.

Keep the code readable and beginner-friendly. Explain what each major file does and how to run it.

Do not generate the whole application as one giant file. Build in small, verifiable milestones.

Before changing existing files, inspect the repository and preserve working code. Do not silently replace project configuration.

If a command fails, investigate the actual error, fix it, rerun the command, and report what happened. Never claim a test passed unless it was run and passed.

Use pinned or compatible dependency versions and provide setup instructions for macOS, Windows, and Linux where practical.

Ask a concise question only when a decision genuinely blocks implementation. Otherwise choose the simplest safe default and record the choice.

# 3. Problem statement

Security tools can generate large volumes of authentication logs, network events, firewall records, and alerts. Manually reviewing each event is time-consuming, and analysts need help identifying suspicious patterns, understanding severity, deciding what to investigate first, and recording a rationale for their decisions.

AI-DIOS aims to consolidate event ingestion, analytics, threat indicators, risk prioritization, explanations, and recommended defensive actions in one interface.

## Example scenario (illustrative, not a measured result)

An uploaded authentication-event CSV shows a high number of failed logins associated with one source IP over a short time interval. The system validates the rows, aggregates failed attempts, detects a possible brute-force pattern, assigns a risk score using documented rules and available model output, explains the factors that contributed, and recommends reviewing the source, affected accounts, and authentication controls.

The example values shown in UI mockups must be labelled as demo data until generated by a real test run.

# 4. Objectives

Import and validate security events from CSV.

Provide a sample dataset so the app can be demonstrated immediately.

Normalize fields and handle missing, malformed, duplicate, and out-of-range values.

Analyze event patterns and identify suspicious behaviour.

Implement at least one auditable detection method and one ML method if a suitable labelled dataset is available.

Calculate a documented, configurable risk score.

Prioritize incidents by severity and risk.

Explain findings using contributing evidence and readable reason codes.

Recommend safe, human-reviewed next steps.

Show event counts, incident summaries, trends, categories, and priority alerts in a responsive dashboard.

Let users inspect an incident and its supporting events.

Record analyst status changes and notes if this can be implemented securely within the available scope.

Include reproducible tests, a technical report, architecture diagrams, and setup instructions.

# 5. Explicit scope and boundaries

## In scope for the minimum viable product (MVP)

Local development and demonstration.

CSV upload and a built-in sample dataset.

Event normalization and validation.

Rule-based detection for selected event patterns.

A reproducible ML classification or anomaly-detection experiment.

Risk scoring and severity bands.

Explanation of rules/features contributing to each finding.

Incident table, filters, event detail view, analytics dashboard.

Backend API and persistent storage.

Unit and integration tests.

Documentation and reproducible setup.

## Stretch goals only after MVP works

Natural-language security analyst assistant grounded in the selected incident data.

Additional datasets and model comparisons.

Role-based authentication.

Exportable incident reports.

Docker Compose.

Audit log and case-management workflow.

Additional log formats such as JSON.

Optional LLM provider integration through a backend adapter.

## Out of scope unless specifically approved

Autonomous incident response.

Live firewall or endpoint control.

Real-time enterprise SIEM replacement.

Production-grade SOC monitoring.

Malware execution or payload generation.

Scanning or testing systems without explicit authorization.

Claims of production readiness or enterprise-grade security without a suitable review.

# 6. Recommended technology stack

Choose a coherent stack and do not mix alternatives without a reason.

## Frontend

React

TypeScript

Vite

Tailwind CSS

Recharts for charts

React Router for pages

A lightweight HTTP client using `fetch` or Axios

Optional: Lucide icons

## Backend

Python 3.11 or another version compatible with selected dependencies

FastAPI

Pydantic request/response schemas

Uvicorn development server

## Analytics and ML

pandas

NumPy

scikit-learn

joblib for serializing a locally trained model

pytest for tests

## Database

SQLite for the first local MVP to reduce setup complexity

SQLAlchemy for persistence and a clean data-access layer

Keep the design portable to PostgreSQL later if needed

## Development and quality

Git

`.env` and `.env.example`

`requirements.txt` or `pyproject.toml`

npm scripts

Ruff or equivalent Python linting

ESLint and TypeScript checks

pytest and frontend test tooling if feasible

Optional Docker Compose after local execution is stable

If the agent recommends a different stack, explain the trade-off before changing it. Avoid adding unnecessary technologies.

# 7. Proposed architecture

Use a modular monolith for the MVP: one frontend, one API service, one local database, and a clearly separated analytics/ML package. Do not begin with microservices.

## Logical layers

**Presentation layer:** React dashboard, upload flow, incident list, incident details, analytics.

**API layer:** FastAPI endpoints, validation, consistent errors, pagination/filtering.

**Ingestion layer:** CSV parsing, file checks, column mapping, row validation, normalization.

**Analytics layer:** aggregation, feature engineering, rule-based detectors, ML inference.

**Risk layer:** severity and risk score based on documented factors.

**Explanation layer:** evidence, triggered rules, feature contributions where supportable, caveats.

**Recommendation layer:** safe response guidance, mapped from finding type and severity.

**Persistence layer:** database models for uploaded datasets, events, incidents, and analyst notes/status.

**Model layer:** reproducible training/evaluation scripts and a versioned model artifact, if ML is used.

**Observability layer:** structured application logs, validation summaries, health endpoint, error handling.

## Data flow

User uploads CSV → API validates file → ingestion service parses and normalizes rows → normalized events are persisted → feature/aggregation service computes indicators → rule engine and optional ML model generate findings → risk engine ranks findings → explanation and recommendation services attach reasons → API returns data → frontend renders dashboard and incident detail

## Architecture deliverables

Mermaid component diagram.

Mermaid data-flow diagram.

Sequence diagram for CSV upload and analysis.

Database ER diagram.

API endpoint table.

Short rationale for each major design decision.

# 8. Event schema and data contract

Design a normalized event model. Do not assume every source contains every field.

Suggested fields (nullable when unavailable):

`id`: server-generated identifier

`timestamp`: normalized UTC timestamp when parseable; retain original value if needed

`source_ip`: validated IP string or null

`destination_ip`: validated IP string or null

`source_port`: integer 0–65535 or null

`destination_port`: integer 0–65535 or null

`protocol`: normalized string or null

`event_type`: authentication, network, firewall, IDS alert, or unknown

`action`: allow, deny, login_success, login_failure, alert, or source-specific value

`username_or_asset`: optional pseudonymized identifier; avoid unnecessary personal data

`bytes_in`, `bytes_out`: non-negative numeric values or null

`failed_login_count`: non-negative integer or null

`duration_seconds`: non-negative number or null

`label`: optional ground-truth label only when supplied by the dataset; do not fabricate labels

`raw_fields`: optional JSON field for traceability, subject to size and privacy controls

`dataset_id`: reference to import batch

`created_at`: server timestamp

Define validation rules, accepted column aliases, rejected-row behaviour, duplicate handling, timestamp parsing, and upload limits. Provide a preview of accepted/rejected rows before or after import and an import summary.

# 9. Detection design

Implement detection as separate, testable components. Keep the rules understandable and configurable.

## Rule-based detection candidates

Repeated failed authentication attempts from a source within a configurable time window.

Many distinct destination ports contacted by one source in a time window, as a possible port scan indicator.

Unusually high denied connections or alert counts.

Unusual traffic volume compared with a documented baseline, if the selected data supports it.

Suspicious event frequency or bursts.

Known malicious indicators only if a reliable, documented source is available; otherwise do not claim reputation lookup.

For each rule, document:

Rule ID and name.

Required fields.

Window/threshold parameters.

Logic and limitations.

Severity mapping.

Unit tests, including boundary cases.

Example events that should and should not trigger it.

Thresholds are initial heuristic settings and must be configurable. Do not present them as universal security truths.

## ML experiment

First inspect candidate datasets and choose a task that is feasible with the fields actually available. A labelled tabular network intrusion dataset may support multiclass classification; an unlabelled or weakly labelled dataset may support anomaly detection. Do not assume every proposed attack category can be detected.

Suggested experimental approach:

Create a reproducible data preparation script.

Record source, license, dataset version, file hash if feasible, row/column counts, label distribution, and exclusions.

Prevent leakage: do not train on identifiers or target-derived features that would trivially reveal the label. Consider duplicate rows and time/group leakage.

Split data into training and held-out test sets; use stratification when appropriate and feasible.

Establish a simple baseline (e.g. DummyClassifier or Logistic Regression).

Compare one suitable model (e.g. Random Forest) or use Isolation Forest for an anomaly-detection task.

Report confusion matrix, precision, recall, F1-score, and per-class metrics when appropriate. Include class imbalance and false-positive/false-negative implications.

Fix random seeds where supported and record library versions and parameters.

Save the model and preprocessing pipeline together if possible.

Evaluate on held-out data and clearly state that benchmark performance on a public dataset does not establish real-world operational performance.

Do not select a model only because its accuracy looks high. Prefer appropriate recall/precision trade-offs and explain the choice.

# 10. Risk scoring and incident prioritization

Build a transparent scoring function with documented inputs. For example, a score may combine:

Rule severity.

Number of relevant events in a time window.

Confidence or strength of a detection.

Number of affected assets/accounts, if available.

Recency.

ML probability or anomaly score, if calibrated/meaningful.

Do not blindly combine incompatible scores. Normalize components, document weights, and add tests. If the ML output is not calibrated, label it as a model score rather than a probability.

Provide:

A numeric risk score, such as 0–100, with explicit formula.

Severity bands such as Low, Medium, High, Critical, with configurable boundaries.

The reasons contributing to the score.

A confidence/uncertainty description only if defensibly calculated; otherwise omit numeric confidence.

A mechanism to avoid counting the same underlying events repeatedly as separate incidents where feasible.

The score is a prioritization aid, not a statement of certainty.

# 11. Explainability and recommendations

Every incident detail should show:

Detection source: rule, ML, or both.

Triggered rule IDs and thresholds.

Supporting event counts and time range.

Relevant source/destination/asset fields, with sensitive data minimized.

ML prediction and model version when applicable.

Factors contributing to risk, where available.

Known limitations and missing fields.

Recommended next steps.

A clear notice that recommendations require human review.

Example recommendation mapping:

Repeated failed logins: inspect authentication logs, confirm whether the source is expected, review targeted accounts, verify MFA and rate-limiting controls, and consider a temporary block only under an approved incident-response process.

Possible port scan: verify whether the source is an authorized scanner, correlate firewall/IDS records, inspect targeted assets, and apply approved filtering if justified.

Unusual outbound traffic: check asset ownership, destination, process/service logs, data transfer context, and endpoint telemetry before deciding whether containment is appropriate.

False positive suspected: allow an analyst to mark it for review and record rationale.

Do not present a language model's free-form answer as verified evidence. If an LLM assistant is added, ground it in server-provided incident facts, display the facts used, and make clear it may be wrong. The core app must function without an LLM.

# 12. Database model

Use SQLAlchemy models and migrations or a documented schema initialization approach. At minimum consider:

`DatasetImport`: file name, upload time, source description, total rows, accepted rows, rejected rows, status, error summary.

`SecurityEvent`: normalized event fields and dataset reference.

`Incident`: title, category, source, severity, risk score, status, first/last seen, evidence summary, model version/rule ID.

`IncidentEvent`: join table linking incidents to relevant events.

`AnalystNote`: incident reference, note, timestamp, author label if authentication exists.

`AuditEntry`: status change or analyst action, timestamp, actor label, previous/new values.

Add indexes for commonly filtered fields such as timestamp, source IP, severity, status, and event type. Avoid storing secrets. Add reasonable upload and record limits.

# 13. Backend API requirements

Use versioned endpoints, e.g. /api/v1. Define request/response schemas, status codes, validation errors, and examples.

Suggested endpoints:

`GET /api/v1/health` — liveness/readiness summary.

`POST /api/v1/datasets/upload` — upload CSV; validate size/type and return import summary.

`GET /api/v1/datasets` — list imports.

`GET /api/v1/datasets/{dataset_id}` — import details and validation summary.

`POST /api/v1/analysis/run` — run analysis for a selected import or dataset.

`GET /api/v1/dashboard/summary` — aggregate metrics for current stored data.

`GET /api/v1/incidents` — paginated, filterable incidents.

`GET /api/v1/incidents/{incident_id}` — incident evidence and explanation.

`PATCH /api/v1/incidents/{incident_id}` — update analyst status, with validation.

`POST /api/v1/incidents/{incident_id}/notes` — add an analyst note if supported.

`GET /api/v1/analytics/trends` — time-bucketed event/incident counts.

`GET /api/v1/analytics/categories` — incident distribution by category.

Optional `GET /api/v1/events` with pagination and filters.

Requirements:

Never accept arbitrary filesystem paths from users.

Validate file type, extension, size, encoding, row/column counts, and allowed columns.

Avoid returning huge unpaginated datasets.

Use consistent JSON error responses.

Enable CORS only for the intended local frontend origin during development.

Add basic request logging without logging secrets or entire sensitive rows.

Add timeouts and sensible limits where relevant.

Do not expose model files or local filesystem contents through API routes.

# 14. Frontend requirements and page design

Build a polished, professional security operations interface. Use accessible contrast, readable typography, responsive layouts, keyboard-friendly controls, clear loading/error/empty states, and consistent design tokens. Avoid fake live data and decorative metrics that do not reflect the backend.

## Page 1: Overview dashboard

Header with AI-DIOS title and environment/status indicator.

Dataset selection/import summary.

KPI cards derived from API data: total events, incidents, high/critical incidents, imports or events requiring review.

Trend chart with time range selector.

Incident category distribution.

Priority incident list.

Recent analysis activity.

Empty state before any data is loaded.

Label sample/demo data clearly.

## Page 2: Data ingestion

CSV drag/drop and browse file.

Supported schema and sample CSV download.

File size/type guidance.

Upload progress and error display.

Import summary: total rows, accepted rows, rejected rows, validation errors.

Preview rows without exposing unnecessary sensitive data.

Clear action to run analysis.

## Page 3: Incidents

Table/list with severity, title/category, risk score, source, first/last seen, status.

Search, filters, sort, pagination.

Severity and status labels.

Click-through to incident detail.

Useful no-results and error states.

## Page 4: Incident detail

Incident summary and risk score.

Why it was flagged: rules and evidence.

Timeline and relevant events.

Detection source and model version where relevant.

Risk-score breakdown.

Recommended next steps and human-review warning.

Status changes and analyst notes if implemented.

Link back to filtered incident list.

## Page 5: Analytics

Events over time.

Incident categories and severity distribution.

Top event sources/affected assets where fields exist.

Filters by dataset, time range, and severity.

Every chart must be based on API data and show an empty state if data is unavailable.

## Page 6: Model evaluation (recommended for academic demonstration)

Dataset metadata and split configuration.

Model name/version and parameters.

Confusion matrix.

Precision, recall, F1, and accuracy where appropriate.

Per-class metrics and class distribution.

Warning that test results apply to the selected dataset and split only.

## Shared UI requirements

Typed API client.

Reusable cards, chart containers, tables, badges, empty states, error alerts, and loading skeletons.

Frontend environment variable such as `VITE_API_BASE_URL`.

Do not put private API keys in frontend environment variables.

Do not hardcode dashboard counts as if they are real.

Provide responsive behaviour for laptop and mobile widths.

# 15. Security and privacy requirements

Treat uploaded CSV files as untrusted input.

Enforce file size and row-count limits.

Parse safely; never execute uploaded content.

Validate IP addresses, timestamps, numeric ranges, and enum fields.

Prevent path traversal and arbitrary file access.

Avoid rendering raw CSV values as HTML.

Keep CORS restrictive.

Use parameterized database operations through the ORM.

Avoid sensitive data in logs and error responses.

Keep secrets out of Git and provide `.gitignore`.

If authentication is not implemented, clearly label the MVP as a local academic prototype, not a multi-user production system.

Use only authorized datasets and systems.

Add a human approval step before any response action; the MVP should recommend actions, not execute them.

# 16. Testing and validation plan

Implement tests before claiming readiness.

## Unit tests

CSV parsing and column alias mapping.

Invalid timestamps and malformed IP addresses.

Missing fields and duplicate rows.

Empty file, oversized file, unsupported file type.

Each detection rule at below/at/above threshold.

Risk-score boundaries and severity mapping.

Recommendation mapping.

API response schemas.

## Integration tests

Upload a valid CSV and confirm accepted/rejected row counts.

Upload an invalid CSV and confirm a useful error.

Run analysis and confirm incidents are stored.

Fetch dashboard summary and compare it with database fixtures.

Fetch incident detail and confirm supporting evidence is linked.

Change status and verify persistence.

Confirm pagination and filters work.

## Frontend checks

Production build succeeds.

TypeScript and lint checks pass.

Loading, empty, error, and populated states render.

Upload form validation behaves correctly.

Charts respond to real API data.

Incident navigation works.

## ML evaluation

Baseline and candidate model evaluated on a held-out set.

Confusion matrix and relevant metrics generated by code.

Data leakage and class imbalance discussed.

Save experiment configuration and random seed.

Record hardware/software environment and runtime if measured.

## Results reporting table

Use a table with columns: Experiment ID, dataset/version, rows used, preprocessing, model/rule version, train/test split, metrics, environment, date, limitations. Populate it only with actual run output. If an experiment has not been run, mark it Not run.

# 17. Repository layout

Create a clear layout similar to:

ai-dios/
  README.md
  .gitignore
  .env.example
  docs/
    project-specification.md
    architecture.md
    data-dictionary.md
    api-reference.md
    test-plan.md
    experiment-log.md
    known-limitations.md
    diagrams/
  backend/
    app/
      main.py
      api/
        routes/
      core/
        config.py
        logging.py
      db/
        base.py
        session.py
        models.py
      schemas/
      services/
        ingestion.py
        preprocessing.py
        detection_rules.py
        ml_inference.py
        risk_scoring.py
        explainability.py
        recommendations.py
        analytics.py
      repositories/
      ml/
        train.py
        evaluate.py
        artifacts/
      tests/
    requirements.txt
    .env.example
  frontend/
    package.json
    vite.config.ts
    src/
      app/
      components/
      pages/
      features/
      services/
        api.ts
      types/
      hooks/
      styles/
  data/
    sample/
      README.md
    processed/
      .gitkeep
  scripts/
    generate_demo_data.py
    run_local.sh
    run_local.ps1

Adjust as implementation needs dictate, but preserve clear separation of concerns. Do not commit large datasets, model artifacts, secrets, local databases, or uploaded user files unless there is a clear reason.

# 18. Sample data strategy

Provide a clearly labelled synthetic sample CSV so a reviewer can run the application without downloading a dataset. Generate plausible benign and suspicious patterns, including:

Ordinary successful authentication events.

Small numbers of failed logins.

A burst of failed logins from one source.

Network events across a range of destination ports.

Denied connections.

A high-volume event burst.

The generator must be deterministic with a fixed seed, document that it is synthetic, and include enough fields to demonstrate the schema. Do not use real people's credentials or sensitive production data.

Synthetic data is for testing application workflow and rule behaviour. It must not be presented as evidence of real-world ML generalization. For an ML benchmark, select and document a suitable public dataset separately.

# 19. Documentation deliverables

Generate and maintain:

`README.md`: overview, features, architecture summary, prerequisites, setup, run commands, demo workflow, tests, limitations.

Architecture diagrams.

Database schema and data dictionary.

API reference with example requests/responses.

Dataset provenance and preprocessing document.

ML experiment methodology and results, only after actual runs.

Test plan and test execution log.

Known limitations and future work.

Project report outline suitable for a B.Tech capstone.

Demo script for a 3–5 minute walkthrough.

Presentation outline with no unsupported claims.

Keep the distinction between planned, implemented, tested, and validated functionality explicit in all documents.

# 20. Required build workflow: implement in phases

Do not attempt to build everything in a single response. Work phase by phase, with working code and verification at each stage.

## Phase 0 — Repository and environment inspection

Ask me to open or create a project directory and identify the operating system.

Inspect existing files before changing anything.

Check installed Python and Node versions.

Produce a concise implementation plan and identify risks.

Do not claim anything has been installed or run unless actually verified.

## Phase 1 — Skeleton and health check

Create backend and frontend scaffolding.

Implement `/api/v1/health`.

Connect frontend to backend.

Add configuration and environment examples.

Provide exact install and run commands.

Verify API health and frontend rendering.

## Phase 2 — Data ingestion

Create normalized schema, database models, CSV validation, import summaries, sample-data generator, and upload UI.

Add tests for valid and invalid input.

Demonstrate one successful import using actual local execution.

## Phase 3 — Rules and risk engine

Implement configurable rule detectors, incident creation, risk scoring, explanations, and recommendations.

Add unit tests including edge cases.

Show actual generated incidents from the sample data.

## Phase 4 — Dashboard and incident workflows

Build dashboard KPIs, charts, incident list, filtering, pagination, and detail page.

Connect all components to the API.

Ensure metrics are derived from stored data, not hardcoded placeholders.

## Phase 5 — ML experiment

Select an appropriate dataset and task based on available time and data.

Build reproducible preprocessing, baseline, candidate model, evaluation, and inference integration.

Save model metadata and report actual metrics.

Keep rule-based and ML findings distinguishable.

## Phase 6 — Testing, hardening, and documentation

Run unit/integration/frontend checks.

Fix failures.

Add security validation and limits.

Write reproducible setup, diagrams, experiment log, limitations, and demo script.

Verify the project from a clean setup as far as the environment allows.

## Phase 7 — Optional enhancements

Only after the MVP works: LLM analyst assistant, Docker Compose, authentication, report export, or additional data formats. Explain cost, privacy, and API-key requirements before enabling any external LLM.

# 21. Definition of done for the MVP

The MVP is ready to demonstrate only when:

A new user can follow README instructions to start the app.

The health endpoint works.

The frontend can upload the provided sample CSV.

The backend validates and stores accepted events.

The app runs analysis and produces traceable incidents.

Risk scores and recommendations have documented logic.

The dashboard displays actual data from the backend.

Incident details show evidence and explanations.

Automated tests have been run and their results are reported honestly.

At least one reproducible ML experiment has been run if ML is claimed as implemented; otherwise it is explicitly marked as pending.

Known limitations are documented.

No fake metrics or unverified completion claims appear in the UI or report.

# 22. How you must work with me

I am a B.Tech CSE student and need beginner-friendly explanations. For every milestone:

State the goal and expected files.

Give the exact commands to run.

Provide complete file contents when creating files, or precise patches when modifying existing files.

Explain where each file belongs.

Tell me what successful output should look like.

Ask me to run commands and share the actual error/output when needed.

Diagnose errors from the actual output.

Do not jump ahead until the current milestone is verified, unless I explicitly request a planning-only answer.

Maintain a checklist of completed, in-progress, blocked, and planned items.

Update the README and technical notes as decisions change.

Keep academic integrity: help me understand the code so I can explain it in a viva.

Do not state that you executed local commands if you cannot access my environment.

# 23. First response required from you

Start by acknowledging this specification and then do only the following:

Ask whether I am using macOS, Windows, or Linux, unless the environment is already known.

Ask whether I have a code editor such as VS Code and whether Python and Node.js are installed, if this is not known.

Give a brief Phase 0 plan.

Do not generate the entire codebase in the first response.

Do not invent project files, test outputs, or completed implementation status.

Wait for my environment details, then begin Phase 0 and Phase 1.

End of master prompt.

# PART B — PROJECT REFERENCE NOTES

# 1. Project identity

**Title:** AI-DIOS — Intelligent Analytics & Cybersecurity Decision Support System

**Academic context:** B.Tech Computer Science & Engineering, final year capstone

**Domain:** Cybersecurity, AI/ML, data analytics, decision support, full-stack web engineering

**Primary users:** Student demonstrator, security analyst persona, project evaluator

**Primary value:** Convert raw security events into prioritized, explainable findings and recommended next steps.

# 2. Suggested first demonstration

Open the dashboard and show the empty state or clearly labelled sample dataset.

Upload the included synthetic sample CSV.

Show import validation counts.

Run analysis.

Open the incidents page and filter for High/Critical severity.

Open a suspicious-authentication incident and show the evidence and triggered rule.

Show the risk-score breakdown and recommendation.

Open analytics and explain that charts reflect the imported events.

If the ML phase is implemented, show the model evaluation page and explain dataset provenance, split, and limitations.

Finish with the current implementation status and known limitations.

# 3. Academic evaluation evidence checklist

Use this to prepare evidence for the university form. Fill in only after actual work:

☐ Correct project title, Project ID, supervisor name/email.

☐ At least three WPRs submitted, as required by the university email.

☐ Architecture and data-flow diagrams.

☐ Module decomposition and technology stack.

☐ Repository tree and descriptions of actual implemented modules.

☐ Screenshots of running app and working API.

☐ Dataset source, provenance, size, preprocessing, and label distribution.

☐ Actual test cases, expected/observed outputs, and test execution evidence.

☐ Actual ML metrics, if the experiment has been run.

☐ Integration status and known defects.

☐ Challenges, corrective actions, limitations, and remaining work.

☐ Clear distinction between completed, partial, and planned work.

☐ Review of the form with the allocated Project Guide.

# 4. Suggested implementation status vocabulary

**Planned:** Design exists; implementation has not started.

**In progress:** Code or configuration is being developed; not yet verified.

**Implemented:** Code exists and the intended feature is present.

**Tested:** A defined test was actually run and passed; record the test.

**Validated:** Evidence supports the intended behaviour under documented conditions.

**Blocked:** Progress depends on a missing requirement, environment, dataset, or decision.

Do not use “completed” as a substitute for tested or validated.

# 5. Important project limitations to acknowledge

Dataset results may not generalize to real networks.

Rule-based heuristics can create false positives and false negatives.

Public intrusion datasets can be imbalanced, outdated, duplicated, or unrepresentative.

Risk scores depend on assumptions and threshold choices.

IP addresses can be spoofed, shared, or misattributed; an IP alone is not proof of maliciousness.

Explainability depends on what the model and input data can actually support.

The local academic MVP is not a replacement for an enterprise SIEM/SOC.

Recommendations are advisory and require human review.

An LLM may hallucinate; it must not invent event facts or independently trigger response actions.

# 6. Prompt for reviewing the project after each milestone

Use this prompt after completing a phase:

“Review the current AI-DIOS repository against the master specification. Inspect the actual files and available test outputs. Report (1) features implemented, (2) features tested and the exact evidence, (3) failures and defects, (4) security/privacy concerns, (5) documentation that is out of date, and (6) the smallest next milestone. Do not infer successful execution from code alone, and do not invent metrics or screenshots. Provide concrete fixes for any verified issues.”

# PART C — QUICK START INSTRUCTIONS FOR USING THIS DOCUMENT

Create a project workspace in your coding tool or local editor.

Upload this document and paste **Part A** as the initial instruction.

Tell the AI your actual operating system and whether Python, Node.js, and a code editor are installed.

Ask it to begin with Phase 0, then Phase 1 only.

Run the commands yourself, share actual errors, and save working code to a local repository.

Commit or back up each working milestone.

Keep screenshots and experiment outputs in a dated evidence folder, but only after generating them.

Before submitting any university form, reconcile every claim with the actual repository and evidence.

Final reminder: This document is a detailed build plan. It does not mean the system has already been built. Use the resulting implementation and real test evidence to report progress accurately.

AI-DIOS Master Project Build Specification  |  Page