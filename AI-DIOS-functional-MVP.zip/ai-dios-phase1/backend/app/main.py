"""AI-DIOS FastAPI entry point."""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.routes import health, platform
from app.core.config import get_settings

settings = get_settings()
app = FastAPI(title=f"{settings.app_name} API", version=settings.app_version,
              description="Local academic cybersecurity analytics and decision support prototype")
app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origin_list,
                   allow_methods=["GET", "POST", "PATCH"], allow_headers=["*"])
app.include_router(health.router, prefix="/api/v1")
app.include_router(platform.router, prefix="/api/v1")
