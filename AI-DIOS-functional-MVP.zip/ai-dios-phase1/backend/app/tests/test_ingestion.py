from app.services.ingestion import parse_csv

def test_parse_csv_accepts_valid_event():
    content = b"timestamp,source_ip,event_type,action,destination_port\n2026-10-28T10:00:00Z,198.51.100.4,authentication,login_failure,22\n"
    rows, rejected, errors, total = parse_csv(content)
    assert total == 1
    assert len(rows) == 1
    assert rejected == 0
    assert rows[0]["source_ip"] == "198.51.100.4"
    assert rows[0]["destination_port"] == 22

def test_parse_csv_rejects_invalid_ip_and_reports_row():
    content = b"timestamp,source_ip,event_type,action\n2026-10-28T10:00:00Z,not-an-ip,authentication,login_failure\n"
    rows, rejected, errors, total = parse_csv(content)
    assert rows == []
    assert rejected == 1
    assert total == 1
    assert any("Row 2" in error for error in errors)

def test_parse_csv_requires_columns():
    from fastapi import HTTPException
    import pytest
    with pytest.raises(HTTPException) as exc:
        parse_csv(b"timestamp,action\n2026-10-28T10:00:00Z,login_failure\n")
    assert exc.value.status_code == 400
