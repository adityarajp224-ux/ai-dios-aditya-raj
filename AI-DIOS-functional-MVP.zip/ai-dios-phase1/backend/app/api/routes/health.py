from fastapi import APIRouter
from sqlalchemy import text
from app.core.config import get_settings
from app.schemas.health import HealthResponse
from app.db.database import engine

router = APIRouter(tags=["health"])

@router.get("/health", response_model=HealthResponse)
def health() -> HealthResponse:
    s = get_settings()
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        db_status = "connected"
    except Exception:
        db_status = "unavailable"
    return HealthResponse(status="ok", app=s.app_name, version=s.app_version,
                          environment=s.app_env, database=db_status)
