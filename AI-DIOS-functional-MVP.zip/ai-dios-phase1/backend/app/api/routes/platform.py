import json
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.db.database import get_db
from app.db.models import Base, DatasetImport, SecurityEvent, Incident
from app.db.database import engine
from app.services.ingestion import parse_csv
from app.services.detection import analyze_dataset

router = APIRouter(tags=["AI-DIOS"])
Base.metadata.create_all(bind=engine)

def incident_dict(i):
    return {"id": i.id, "dataset_id": i.dataset_id, "title": i.title, "category": i.category,
            "source_ip": i.source_ip, "severity": i.severity, "risk_score": i.risk_score,
            "summary": i.summary, "evidence": json.loads(i.evidence_json), "recommendation": i.recommendation,
            "first_seen": i.first_seen, "last_seen": i.last_seen, "status": i.status}

@router.post("/datasets/upload")
async def upload_dataset(file: UploadFile = File(...), db: Session = Depends(get_db)):
    if not file.filename or not file.filename.lower().endswith(".csv"):
        raise HTTPException(400, "Please upload a .csv file.")
    content = await file.read()
    rows, rejected, errors, total = parse_csv(content)
    item = DatasetImport(filename=file.filename[:255], total_rows=total, accepted_rows=len(rows), rejected_rows=rejected, status="completed" if rows else "failed")
    db.add(item); db.flush()
    for row in rows:
        db.add(SecurityEvent(dataset_id=item.id, timestamp=row["timestamp"], source_ip=row["source_ip"],
            destination_ip=row.get("destination_ip"), destination_port=row.get("destination_port"),
            event_type=row["event_type"], action=row["action"], username=row.get("username"),
            protocol=row.get("protocol"), bytes_out=row.get("bytes_out"), raw_json=row.get("_raw")))
    db.commit(); db.refresh(item)
    return {"id": item.id, "filename": item.filename, "total_rows": total, "accepted_rows": len(rows),
            "rejected_rows": rejected, "errors": errors, "status": item.status,
            "message": "Import saved. Run analysis to generate incidents." if rows else "No valid rows were imported."}

@router.get("/datasets")
def list_datasets(db: Session = Depends(get_db)):
    imports = db.query(DatasetImport).order_by(DatasetImport.imported_at.desc()).limit(100).all()
    return [{"id": d.id, "filename": d.filename, "imported_at": d.imported_at.isoformat(),
             "total_rows": d.total_rows, "accepted_rows": d.accepted_rows, "rejected_rows": d.rejected_rows,
             "status": d.status} for d in imports]

@router.get("/datasets/{dataset_id}")
def get_dataset(dataset_id: int, db: Session = Depends(get_db)):
    d = db.get(DatasetImport, dataset_id)
    if not d: raise HTTPException(404, "Dataset import not found.")
    return {"id": d.id, "filename": d.filename, "imported_at": d.imported_at.isoformat(),
            "total_rows": d.total_rows, "accepted_rows": d.accepted_rows, "rejected_rows": d.rejected_rows, "status": d.status}

@router.post("/analysis/run")
def run_analysis(dataset_id: int, db: Session = Depends(get_db)):
    d = db.get(DatasetImport, dataset_id)
    if not d: raise HTTPException(404, "Dataset import not found.")
    incidents = analyze_dataset(db, dataset_id)
    return {"dataset_id": dataset_id, "events_analyzed": d.accepted_rows, "incidents_created": len(incidents),
            "incidents": [incident_dict(i) for i in incidents]}

@router.get("/incidents")
def list_incidents(dataset_id: int | None = None, severity: str | None = None, status: str | None = None, db: Session = Depends(get_db)):
    q = db.query(Incident)
    if dataset_id is not None: q = q.filter(Incident.dataset_id == dataset_id)
    if severity: q = q.filter(Incident.severity == severity)
    if status: q = q.filter(Incident.status == status)
    return [incident_dict(i) for i in q.order_by(Incident.risk_score.desc(), Incident.created_at.desc()).limit(500).all()]

@router.get("/incidents/{incident_id}")
def get_incident(incident_id: int, db: Session = Depends(get_db)):
    i = db.get(Incident, incident_id)
    if not i: raise HTTPException(404, "Incident not found.")
    return incident_dict(i)

@router.patch("/incidents/{incident_id}")
def update_incident(incident_id: int, payload: dict, db: Session = Depends(get_db)):
    i = db.get(Incident, incident_id)
    if not i: raise HTTPException(404, "Incident not found.")
    status = payload.get("status")
    if status not in {"Open", "Investigating", "Resolved", "False Positive"}:
        raise HTTPException(400, "Status must be Open, Investigating, Resolved, or False Positive.")
    i.status = status; db.commit(); db.refresh(i)
    return incident_dict(i)

@router.get("/dashboard/summary")
def dashboard_summary(db: Session = Depends(get_db)):
    total_events = db.query(func.count(SecurityEvent.id)).scalar() or 0
    total_incidents = db.query(func.count(Incident.id)).scalar() or 0
    high = db.query(func.count(Incident.id)).filter(Incident.severity.in_(["High", "Critical"])).scalar() or 0
    imports = db.query(func.count(DatasetImport.id)).scalar() or 0
    by_severity = {s: db.query(func.count(Incident.id)).filter(Incident.severity == s).scalar() or 0 for s in ["Critical", "High", "Medium", "Low"]}
    recent = db.query(Incident).order_by(Incident.created_at.desc()).limit(5).all()
    return {"total_events": total_events, "total_incidents": total_incidents, "high_priority": high, "imports": imports,
            "by_severity": by_severity, "recent_incidents": [incident_dict(i) for i in recent]}

@router.get("/analytics")
def analytics(db: Session = Depends(get_db)):
    categories = db.query(Incident.category, func.count(Incident.id)).group_by(Incident.category).all()
    statuses = db.query(Incident.status, func.count(Incident.id)).group_by(Incident.status).all()
    return {"categories": [{"name": n, "count": c} for n, c in categories],
            "statuses": [{"name": n, "count": c} for n, c in statuses]}
