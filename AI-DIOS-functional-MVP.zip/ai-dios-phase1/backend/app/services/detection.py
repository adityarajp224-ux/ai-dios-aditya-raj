from collections import defaultdict
from datetime import datetime
import json
from sqlalchemy.orm import Session
from app.db.models import SecurityEvent, Incident

def analyze_dataset(db: Session, dataset_id: int):
    events = db.query(SecurityEvent).filter(SecurityEvent.dataset_id == dataset_id).all()
    # Re-running analysis replaces this dataset's previous generated incidents.
    db.query(Incident).filter(Incident.dataset_id == dataset_id).delete()
    groups = defaultdict(list)
    for e in events:
        groups[e.source_ip].append(e)
    created = []
    for ip, items in groups.items():
        failures = [e for e in items if any(x in e.action.lower() for x in ("fail", "denied", "blocked")) or "auth_failure" in e.event_type.lower()]
        ports = {e.destination_port for e in items if e.destination_port is not None}
        times = sorted(e.timestamp for e in items)
        if len(failures) >= 5:
            score = min(98, 55 + min(35, 2 * len(failures)))
            severity = "Critical" if score >= 90 else "High" if score >= 75 else "Medium"
            evidence = {"failed_or_denied_events": len(failures), "total_source_events": len(items), "first_seen": min(e.timestamp for e in failures), "last_seen": max(e.timestamp for e in failures), "rule_id": "AUTH-001"}
            incident = Incident(dataset_id=dataset_id, title="Repeated failed authentication / denied activity", category="Brute-force indicator", source_ip=ip, severity=severity, risk_score=score, summary=f"{len(failures)} failed or denied events were associated with {ip}. This pattern may indicate credential guessing or repeated blocked access.", evidence_json=json.dumps(evidence), recommendation="Review authentication logs and affected accounts, verify whether the source is expected, check MFA and rate-limiting controls, and follow your approved response process before blocking any source.", first_seen=evidence["first_seen"], last_seen=evidence["last_seen"])
            db.add(incident); created.append(incident)
        if len(ports) >= 8:
            score = min(95, 50 + len(ports))
            severity = "Critical" if score >= 90 else "High" if score >= 75 else "Medium"
            evidence = {"distinct_destination_ports": len(ports), "ports": sorted(ports), "total_source_events": len(items), "rule_id": "NET-001"}
            incident = Incident(dataset_id=dataset_id, title="Possible port scanning activity", category="Port scan indicator", source_ip=ip, severity=severity, risk_score=score, summary=f"The source contacted {len(ports)} distinct destination ports. This may be an authorized scan or reconnaissance activity and needs context.", evidence_json=json.dumps(evidence), recommendation="Confirm whether the source is an authorized scanner, correlate firewall/IDS logs, inspect targeted assets, and follow approved filtering procedures if the activity is unauthorized.", first_seen=min(times) if times else "", last_seen=max(times) if times else "")
            db.add(incident); created.append(incident)
    db.commit()
    for inc in created: db.refresh(inc)
    return created
