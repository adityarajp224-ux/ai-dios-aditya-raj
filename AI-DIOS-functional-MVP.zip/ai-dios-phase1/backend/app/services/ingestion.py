import csv, io, json, ipaddress
from datetime import datetime
from fastapi import HTTPException

ALIASES = {
    "timestamp": ["timestamp", "time", "event_time", "datetime"],
    "source_ip": ["source_ip", "src_ip", "src", "ip", "srcip"],
    "event_type": ["event_type", "type", "category"],
    "action": ["action", "status", "event_action"],
    "destination_ip": ["destination_ip", "dst_ip", "dest_ip", "dst"],
    "destination_port": ["destination_port", "dst_port", "dest_port", "port"],
    "username": ["username", "user", "account"],
    "protocol": ["protocol", "proto"],
    "bytes_out": ["bytes_out", "out_bytes", "bytes"],
}
REQUIRED = {"timestamp", "source_ip", "event_type", "action"}

def parse_csv(content: bytes):
    if len(content) > 5 * 1024 * 1024:
        raise HTTPException(413, "File exceeds the 5 MB limit.")
    try:
        text = content.decode("utf-8-sig")
    except UnicodeDecodeError:
        raise HTTPException(400, "CSV must be UTF-8 encoded.")
    if not text.strip():
        raise HTTPException(400, "CSV file is empty.")
    try:
        reader = csv.DictReader(io.StringIO(text))
        if not reader.fieldnames:
            raise HTTPException(400, "CSV header row is missing.")
        normalized_headers = {h.strip().lower(): h for h in reader.fieldnames if h}
        mapping = {}
        for canonical, aliases in ALIASES.items():
            for alias in aliases:
                if alias in normalized_headers:
                    mapping[canonical] = normalized_headers[alias]
                    break
        missing = sorted(REQUIRED - set(mapping))
        if missing:
            raise HTTPException(400, f"Missing required columns: {', '.join(missing)}")
        accepted, rejected, errors = [], 0, []
        for line_no, raw in enumerate(reader, start=2):
            if len(accepted) + rejected >= 20000:
                errors.append("Import stopped at the 20,000-row safety limit.")
                break
            row = {key: (raw.get(src) or "").strip() for key, src in mapping.items()}
            try:
                if not row.get("timestamp") or not row.get("source_ip") or not row.get("event_type") or not row.get("action"):
                    raise ValueError("missing required value")
                ipaddress.ip_address(row["source_ip"])
                # Preserve source timestamp but require it to be parseable.
                parsed = datetime.fromisoformat(row["timestamp"].replace("Z", "+00:00"))
                row["timestamp"] = parsed.isoformat()
                port = row.get("destination_port", "")
                if port:
                    port_num = int(port)
                    if not 0 <= port_num <= 65535: raise ValueError("destination_port must be 0–65535")
                    row["destination_port"] = port_num
                else: row["destination_port"] = None
                b = row.get("bytes_out", "")
                if b:
                    b_num = int(b)
                    if b_num < 0: raise ValueError("bytes_out cannot be negative")
                    row["bytes_out"] = b_num
                else: row["bytes_out"] = None
                row["source_ip"] = str(ipaddress.ip_address(row["source_ip"]))
                for optional in ("destination_ip", "username", "protocol"):
                    row[optional] = row.get(optional) or None
                if row["destination_ip"]:
                    ipaddress.ip_address(row["destination_ip"])
                row["event_type"] = row["event_type"].lower()[:50]
                row["action"] = row["action"].lower()[:50]
                row["_raw"] = json.dumps(raw)
                accepted.append(row)
            except Exception as exc:
                rejected += 1
                if len(errors) < 20:
                    errors.append(f"Row {line_no}: {str(exc) or 'invalid row'}")
        return accepted, rejected, errors, len(accepted)+rejected
    except csv.Error as exc:
        raise HTTPException(400, f"Could not parse CSV: {exc}")
