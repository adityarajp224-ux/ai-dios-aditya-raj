"""Application settings, read from environment variables (or backend/.env).

Why: keeps configuration (and any future secrets) out of source code.
"""
from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "AI-DIOS"
    app_version: str = "0.1.0"
    app_env: str = "development"
    database_url: str = "sqlite:///./aidios.db"
    # Comma-separated list of allowed frontend origins (kept restrictive on purpose).
    cors_origins: str = "http://localhost:5173,http://127.0.0.1:5173"

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @property
    def cors_origin_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()
