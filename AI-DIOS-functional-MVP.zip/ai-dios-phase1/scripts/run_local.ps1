# Windows: run backend and frontend in two separate terminals (see README).
Write-Host "Terminal 1: cd backend; .\.venv\Scripts\Activate.ps1; uvicorn app.main:app --reload --port 8000"
Write-Host "Terminal 2: cd frontend; npm run dev"
