#!/usr/bin/env python3
"""Generate a clearly synthetic security-events CSV for local demonstrations."""
import csv, random
from datetime import datetime, timedelta, timezone
from pathlib import Path

OUT = Path(__file__).resolve().parents[1] / "data" / "sample" / "synthetic_security_events.csv"
random.seed(42)
now = datetime.now(timezone.utc).replace(microsecond=0)
rows = []
benign_ips = ["192.0.2.10", "192.0.2.11", "198.51.100.7"]
for i in range(45):
    t = now - timedelta(minutes=random.randint(0, 720))
    ip = random.choice(benign_ips)
    rows.append({"timestamp": t.isoformat(), "source_ip": ip, "destination_ip": "203.0.113.10",
                 "destination_port": random.choice([22, 53, 80, 443]), "event_type": "authentication",
                 "action": "login_success",
                 "username": random.choice(["analyst", "student", "service"]), "protocol": "TCP", "bytes_out": random.randint(0, 5000)})
# Controlled repeated-failure pattern
for i in range(12):
    t = now - timedelta(minutes=12-i)
    rows.append({"timestamp": t.isoformat(), "source_ip": "198.51.100.44", "destination_ip": "203.0.113.10",
                 "destination_port": 22, "event_type": "authentication", "action": "login_failure",
                 "username": "admin", "protocol": "TCP", "bytes_out": 0})
# Controlled broad port pattern
for port in [20, 21, 22, 23, 25, 53, 80, 110, 143, 443]:
    rows.append({"timestamp": (now-timedelta(minutes=random.randint(1, 30))).isoformat(), "source_ip": "203.0.113.77",
                 "destination_ip": "192.0.2.50", "destination_port": port, "event_type": "network_connection",
                 "action": "connection_attempt", "username": "", "protocol": "TCP", "bytes_out": random.randint(0, 200)})
OUT.parent.mkdir(parents=True, exist_ok=True)
with OUT.open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=["timestamp","source_ip","destination_ip","destination_port","event_type","action","username","protocol","bytes_out"])
    writer.writeheader(); writer.writerows(rows)
print(f"Wrote {len(rows)} SYNTHETIC demonstration events to {OUT}")
