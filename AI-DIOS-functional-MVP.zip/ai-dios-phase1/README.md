# AI-DIOS — Intelligent Analytics & Cybersecurity Decision Support System

Local academic prototype for importing security events, applying transparent detection heuristics, prioritizing findings, and presenting evidence-backed recommendations. This is not a production SIEM or an automated response tool.

## Current functional scope
- React + TypeScript + Vite frontend.
- FastAPI backend with health endpoint and API documentation.
- CSV upload and validation (5 MB / 20,000-row limits).
- SQLite persistence for dataset imports and normalized security events.
- Rule-based indicators: repeated failed/denied activity and possible port scanning.
- Documented 0–100 heuristic risk scores, severity, evidence, and human-reviewed recommendations.
- Incident status workflow and dashboard/analytics based on stored data.
- Deterministic synthetic dataset generator.

ML model training/evaluation is not yet implemented. Do not report ML metrics until a reproducible experiment has actually been run.

## Requirements
Python 3.11+ and Node.js 20+.

## Setup (macOS)
From the project root:
```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
cd ../frontend
npm install
cp .env.example .env
```
If either `.env` already exists, preserve it and check its settings rather than overwriting it.

## Run
Terminal 1:
```bash
cd backend
source .venv/bin/activate
uvicorn app.main:app --reload --port 8000
```
Terminal 2:
```bash
cd frontend
npm run dev
```
Open http://localhost:5173. API docs: http://localhost:8000/docs.

## Create synthetic demo data
From the project root:
```bash
python3 scripts/generate_demo_data.py
```
Then open Data Ingestion and upload `data/sample/synthetic_security_events.csv`. The data is synthetic and intended for demonstrating the application workflow, not real-world threat prevalence or ML generalization.

## Suggested demonstration
1. Open Overview and show current database-derived counts.
2. Upload the synthetic CSV in Data Ingestion.
3. Review accepted/rejected row counts and import history.
4. Run threat analysis.
5. Open Incidents, inspect evidence and risk scoring, and change a status.
6. Return to Overview and Analytics to show data-derived summaries.

## Tests
```bash
cd backend
source .venv/bin/activate
python -m pytest -q
```
Frontend:
```bash
cd frontend
npm run typecheck
npm run lint
npm run build
```

## Rules and limitations
- `AUTH-001`: flags at least five failed/denied events associated with one source IP.
- `NET-001`: flags at least eight distinct destination ports associated with one source IP.
- These are transparent demonstration heuristics, not universal thresholds.
- IPs in the sample dataset are documentation/reserved example ranges.
- Risk scores prioritize investigation; they do not prove maliciousness.
- Recommendations are advisory. No automatic IP blocking or disruptive response is performed.
- ML evaluation is pending.
